package org.example.geometryproject.utilities;


import javafx.geometry.Point2D;

public class Point extends Point2D {
    public Point(double v, double v1) {
        super(v, v1);
    }

    void translate(double v, double v1) {

    }

    void setPoint(double v, double v1) {
    }
}
