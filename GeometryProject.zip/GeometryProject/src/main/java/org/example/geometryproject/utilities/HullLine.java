package org.example.geometryproject.utilities;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;

public class HullLine {
    public Point2D p1;
    public Point2D p2;

    public HullLine(Point2D p1, Point2D p2) {
        this.p1 = p1;
        this.p2 = p2;
    }

    public void setStroke(Color color) {

    }

    public void setStrokeWidth(int i) {

    }
}